# 苍井老师版《没出息》MV AI改编


## 基础环境准备

### 1. 电脑需要有 Nvdia 显卡, 安装 Linux 系统, 显卡驱动要先装好.

### 2. 安装docker和拉取镜像 (中国大陆需要魔法)

```
# 卸载旧版本（可选）
sudo apt remove docker docker-engine docker.io containerd runc -y

# 安装依赖包
sudo apt update
sudo apt install -y ca-certificates curl gnupg lsb-release

# 添加 Docker 官方源
sudo mkdir -p /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg

# 添加源列表：
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
  https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# 安装 Docker Engine + CLI + Compose
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# 测试是否安装成功
sudo docker run hello-world

# 可选：允许普通用户使用 docker（无需 sudo）
sudo usermod -aG docker $USER
newgrp docker

# 启动与开机自启
sudo systemctl enable docker
sudo systemctl start docker
sudo systemctl status docker

# 拉取docker镜像 nvidia/cuda:12.8.1
docker pull nvidia/cuda:12.8.1-cudnn-devel-ubuntu22.04
```

### 3. 拉取 comfyui

```
git clone https://github.com/comfyanonymous/ComfyUI.git
```

### 4. 复制 Dockerfile 到 ComfyUI, 创建 comfyui 镜像

```
cd /your/path/aoi_unpromising_docker
http_proxy="http://192.168.0.222:20171"      # 修改为代理端口
git clone https://github.com/comfyanonymous/ComfyUI.git       # 拉取comfyui
mv Dockerfile ./ComfyUI/ && mv sources.list ./ComfyUI/ && cd ComfyUI/      # 复制 Dockerfile sources.list 到 ComfyUI/ 

# 创建镜像
DOCKER_BUILDKIT=1 docker build --build-arg http_proxy=${http_proxy} --build-arg https_proxy=${http_proxy} -t comfyui_docker .
```

### 5. 下载工作流

```
wget 
```


## rsync 上传命令(可选)

```
server_ip="192.168.0.222"      # 修改为服务器 IP
aoi_unpromising_path="/Users/senmalay/v_programs/dev/github_test/aoi_useless_docker"
rsync -avzP --exclude '.venv'  "${aoi_unpromising_path}"  zw@${server_ip}:/deploy/programs/
```
