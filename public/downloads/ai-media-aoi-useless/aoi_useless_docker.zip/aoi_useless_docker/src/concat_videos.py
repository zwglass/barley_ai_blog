import sys
from pathlib import Path
from tqdm import tqdm      # pip install tqdm
import shutil

project_path = Path(__file__).resolve().parent.parent
src_path = Path(__file__).resolve().parent
sys.path.append(str(src_path))

from utils.utils_video_handle import VideoHandle    # 图片基本操作


if __name__ == '__main__':
    # 运行: python src/concat_videos.py

    cls_videohandle = VideoHandle()    # 视频基本操作

    dir_path = project_path / 'aoi' / 'source_002_infer'
    output_video_path = dir_path.parent / f'{dir_path.name}.mp4'

    cls_videohandle.concat_videos_in_folder(folder_path=str(dir_path), output_path=str(output_video_path))
    print('Concated video path:', str(output_video_path))
