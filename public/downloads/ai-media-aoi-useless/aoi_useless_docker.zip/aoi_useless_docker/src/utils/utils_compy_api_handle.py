from pathlib import Path
import requests
import os
import re
import copy
import uuid
import time
import json
from io import BytesIO


class ComfyApiHandle:
    """
    from utils.comfy_api_handle import ComfyApiHandle()           comfyui api 操作
    """
    def __init__(self):
        self.tmp_dir_path = Path(__file__).resolve().parent.parent.parent / 'tmp'
        self.comfy_url = None
        if not self.tmp_dir_path.is_dir():
            self.tmp_dir_path.mkdir(parents=True, exist_ok=True)
        self.dir_path_comfy_apis = Path(__file__).resolve().parent.parent.parent / 'comfy_apis'

        self.video_saver = ComfyUIVideoSaver()

    def api_inference(self, comfy_url, comfy_api_workflow, output_dir=None):
        # comfy api 请求推理
        self.comfy_url = re.sub(r'/$', '', comfy_url)     # 统一url格式, 去掉结尾 斜杠

        api_url = f"{self.comfy_url}/api/prompt"
        api_dict = {"prompt": comfy_api_workflow, "client_id": str(uuid.uuid4())}
        response = requests.post(api_url, json=api_dict)
        res_json = response.json()
        prompt_id = res_json.get('prompt_id', None)
        if prompt_id is None:
            print(f"API运行失败，返回的 prompt id 为：{prompt_id}")
            return None
        
        print('api_inference finished...')
        result_files = self.video_saver.wait_and_save_video(comfy_url=comfy_url, prompt_id=prompt_id, output_dir=output_dir)
        return result_files

    def upload_file(self, local_file_path):
        """
        将本地文件上传至服务器
        """
        with open(local_file_path, 'rb') as f:
            upload_response = requests.post(
                f"{self.comfy_url}/api/upload/image",
                files={"image": f}
            )
            if upload_response.status_code == 200:
                new_image_filename = upload_response.json().get('name', None)
                return new_image_filename
            else:
                print(f"文件上传失败，{upload_response}")
                return None
            
    def update_api_workflow_wan22_animate(self, comfy_url, local_video_path, local_img_path, workflow):
        # 更新 comfy_apis/video_wan2_2_14B_animate.json api 工作流
        self.comfy_url = re.sub(r'/$', '', comfy_url)     # 统一url格式, 去掉结尾 斜杠

        uploaded_video_name = self.upload_file(local_file_path=local_video_path)
        uploaded_img_name = self.upload_file(local_file_path=local_img_path)
        if uploaded_video_name is None or uploaded_img_name is None:
            return None
        
        ret_workflow = copy.deepcopy(workflow)
        # 更新 video 名, image 名
        ret_workflow["145"]["inputs"]["file"] = uploaded_video_name
        ret_workflow["10"]["inputs"]["image"] = uploaded_img_name
        return ret_workflow
    
    def read_comfy_api_workflow(self, workflow_file_name:str, dir_path=None) -> dict:
        # 读取comfy api promtp
        if dir_path is None:
            dir_path = str(self.dir_path_comfy_apis)
        workflow_file_path = Path(dir_path) / workflow_file_name
        workflow_obj = self.read_json_file(str(workflow_file_path))
        return workflow_obj
    
    def read_json_file(self, json_path):
        """
        读取工作流文件
        """
        wf_loaded = None
        with open(json_path, 'r', encoding='utf-8') as f:
            wf_loaded = json.load(f)  # 正确用法：先打开文件，再传递给 json.load
        return wf_loaded


class ComfyUIVideoSaver:
    """
    下载视频文件
    """
    def __init__(self):
        self.tmp_dir_path = Path(__file__).resolve().parent.parent.parent / 'tmp'
        if not self.tmp_dir_path.is_dir():
            self.tmp_dir_path.mkdir(parents=True, exist_ok=True)
        self.comfy_url = None
        self.output_dir = str(self.tmp_dir_path)
        self.prompt_id = None

    def wait_and_save_video(self, comfy_url, prompt_id, output_dir=None, timeout=500):
        """等待任务完成并保存视频"""
        self.comfy_url = re.sub(r'/$', '', comfy_url)     # 统一url格式, 去掉结尾 斜杠
        if output_dir is None:
            self.output_dir = str(self.tmp_dir_path)
        self.prompt_id = prompt_id


        start_time = time.time()
        downloaded = False
        while time.time() - start_time < timeout:
            if downloaded:
                break
            try:
                # 检查队列状态
                queue_response = requests.get(f"{comfy_url}/queue")
                queue_data = queue_response.json()
                
                # 检查是否在队列中
                in_queue = any(item[1] == prompt_id for item in queue_data.get('queue_running', []))
                in_queue |= any(item[1] == prompt_id for item in queue_data.get('queue_pending', []))
                
                if not in_queue:
                    # 不在队列中，说明已完成，获取历史记录
                    print('start download...')
                    history_response = requests.get(f"{comfy_url}/history/{prompt_id}")
                    history_data = history_response.json()
                    # print('prompt_id:', prompt_id)
                                    
                    if prompt_id in history_data:
                        # 使用get_video_from_save_video_node保存视频
                        return self.get_video_from_save_video_node(history_data)
                    downloaded = True
                    break
                
                time.sleep(2)  # 等待2秒再次检查
                
            except Exception as e:
                print(f"检查队列状态失败: {e}")
                time.sleep(2)
        
        if not downloaded:
            print("超时，未找到视频文件")
            return []
    
    def get_video_from_save_video_node(self, history_data):
        """从SaveVideo节点获取视频文件"""
        try:
            # 获取历史记录
            # outputs = history_data.get(self.prompt_id, {}).get('outputs', {})
            outputs = history_data[self.prompt_id]['outputs']
            
            # 查找SaveVideo节点的输出
            video_files = []
            for node_id, node_output in outputs.items():
                # SaveVideo节点通常输出视频文件
                # print('node_output keys:', node_output.keys())
                if 'movies' in node_output:
                    for movie in node_output['movies']:
                        video_files.append({
                            'filename': movie['filename'],
                            'subfolder': movie.get('subfolder', ''),
                            'type': movie.get('type', 'output')
                        })

                if 'images' in node_output:
                    for movie in node_output['images']:
                        video_files.append({
                            'filename': movie['filename'],
                            'subfolder': movie.get('subfolder', ''),
                            'type': movie.get('type', 'output')
                        })
                
                # 也可能在gifs中（如果是GIF格式）
                if 'gifs' in node_output:
                    for gif in node_output['gifs']:
                        video_files.append({
                            'filename': gif['filename'],
                            'subfolder': gif.get('subfolder', ''),
                            'type': gif.get('type', 'output')
                        })
            
            # 下载视频文件
            downloaded_files = []
            for video in video_files:
                saved_path = self.download_file(
                    video['filename'], 
                    video['subfolder'],
                    video['type'],
                    self.output_dir
                )
                if saved_path:
                    downloaded_files.append(saved_path)
            
            return downloaded_files
            
        except Exception as e:
            print(f"获取视频文件失败: {e}")
            return []
    
    def download_file(self, filename, subfolder, type, output_dir):
        """下载文件到本地"""
        try:
            # 构建文件URL
            file_url = f"{self.comfy_url}/view"
            params = {
                'filename': filename,
                'subfolder': subfolder,
                'type': type
            }
            
            # 下载文件
            response = requests.get(file_url, params=params, stream=True)
            response.raise_for_status()
            
            # 确保输出目录存在
            os.makedirs(output_dir, exist_ok=True)
            
            # 保存文件
            file_path = os.path.join(output_dir, filename)
            with open(file_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            print(f"视频文件已保存: {file_path}")
            return file_path
            
        except Exception as e:
            print(f"下载文件失败: {e}")
            return None
