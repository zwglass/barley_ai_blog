import argparse
import subprocess
import os
from pathlib import Path


def split_video(input_path: str, output_dir: str = None, segment_time: int = None,
                start_time: str = None, end_time: str = None):
    """
    使用 FFmpeg 分割/裁剪视频：
    - 使用可选映射：-map 0:v? -map 0:a?（自动有则映射，无则忽略）
    - 排除 data/tmcd（以及可选附件流）
    - 分段时重置时间戳，避免黑频
    - 裁剪使用输入侧 seek，搭配 -c copy 无重编码
    """

    if output_dir is None:
        output_dir = str(Path(input_path).parent / Path(input_path).stem)
    os.makedirs(output_dir, exist_ok=True)

    if segment_time:  # 按时长分段
        output_pattern = os.path.join(output_dir, "segment_%03d.mp4")
        command = [
            "ffmpeg", "-hide_banner", "-y",
            "-fflags", "+genpts",
            "-i", input_path,
            "-c", "copy",
            # ✅ 可选映射：有就带上，没有就忽略（不再需要探测）
            "-map", "0:v?",
            "-map", "0:a?",
            # 排除不受支持的数据流/时间码/附件（可选）
            "-map", "-0:d",           # data（包含 tmcd）
            "-map", "-0:t?",          # attachments（有些容器不支持）
            # 清理 metadata，避免 timecode 继承
            "-map_metadata", "-1",
            # 分段与时间戳
            "-f", "segment",
            "-segment_time", str(segment_time),
            "-reset_timestamps", "1",
            "-avoid_negative_ts", "make_zero",
            "-movflags", "+faststart",
            output_pattern
        ]

    elif start_time and end_time:  # 按时间裁剪单段
        output_file = os.path.join(output_dir, "clip.mp4")
        command = [
            "ffmpeg", "-hide_banner", "-y",
            # 输入侧 seek 更稳定（配合 -c copy）
            "-ss", start_time,
            "-to", end_time,
            "-fflags", "+genpts",
            "-i", input_path,
            "-c", "copy",
            "-map", "0:v?",
            "-map", "0:a?",
            "-map", "-0:d",
            "-map", "-0:t?",
            "-map_metadata", "-1",
            "-avoid_negative_ts", "make_zero",
            "-movflags", "+faststart",
            output_file
        ]
    else:
        raise ValueError("请提供 segment_time 或 start_time 和 end_time 参数。")

    print("🧩 运行命令:", " ".join(command))
    subprocess.run(command, check=True)
    print("✅ 视频分割完成！")


if __name__ == "__main__":
    # 运行命令 python src/split_video.py --input aoi/source_002.mp4 --segment_time 5
    input_video_path = None

    parser = argparse.ArgumentParser(description="使用 FFmpeg 分割视频")
    parser.add_argument("--input", required=False, help="输入视频路径")
    parser.add_argument("--output", required=False, help="输出目录")
    parser.add_argument("--segment_time", type=int, help="每段视频的时长（秒）")
    parser.add_argument("--start_time", help="起始时间，格式 00:00:10")
    parser.add_argument("--end_time", help="结束时间，格式 00:00:30")

    args = parser.parse_args()

    input_path = input_video_path if input_video_path is not None else args.input
    split_video(
        input_path=input_path,
        output_dir=args.output,
        segment_time=args.segment_time,
        start_time=args.start_time,
        end_time=args.end_time
    )
