import sys
from pathlib import Path
from tqdm import tqdm      # pip install tqdm
import shutil

project_path = Path(__file__).resolve().parent.parent
src_path = Path(__file__).resolve().parent
sys.path.append(str(src_path))

from utils.utils_compy_api_handle import ComfyApiHandle           # comfyui api 操作
from utils.utils_video_handle import VideoHandle    # 图片基本操作

def move_movie(source_video_path, infer_video_path):
    # 移动视频文件
    source_video_stem = Path(source_video_path).stem
    source_video_dir_name = Path(source_video_path).parent.name
    target_video_suffix = Path(infer_video_path).suffix
    output_dir = Path(source_video_path).parent.parent / f'{source_video_dir_name}_infer'
    if not output_dir.is_dir():
        output_dir.mkdir(parents=True, exist_ok=True)
    output_video_path = str(output_dir / f'{source_video_stem}{target_video_suffix}')
    shutil.move(infer_video_path, output_video_path)
    return output_video_path


if __name__ == "__main__":
    # 运行: python src/main_req_wan_animate.py

    cls_videohandle = VideoHandle()    # 视频基本操作
    cls_api_handle = ComfyApiHandle()           # comfyui api 操作

    comfy_url = 'http://change.server.url:8189'

    videos_dir = project_path / 'aoi' / 'source_002'
    replace_human_img_path = project_path / 'aoi' / 'aoi_1.jpeg'
    workflow_file_name = 'video_wan2_2_14B_animate.json'
    workflow_obj = cls_api_handle.read_comfy_api_workflow(workflow_file_name)    # 读取基础工作流

    videos_path = cls_videohandle.get_videos_paths_in_dir(folder_path=str(videos_dir))     # 读取全部视频文件路径

    # 循环替换人物
    results = []
    loop_idx = -1
    for v_p in tqdm(videos_path, desc='WanAnimateAPI', total=len(videos_path)):
        # 循环推理
        workflow_updated = cls_api_handle.update_api_workflow_wan22_animate(comfy_url=comfy_url, local_video_path=v_p, local_img_path=replace_human_img_path, workflow=workflow_obj)    # 读取基础工作流
        downloaded_videos = cls_api_handle.api_inference(comfy_url=comfy_url, comfy_api_workflow=workflow_updated)
        if len(downloaded_videos) > 0:
            current_video_path = move_movie(v_p, downloaded_videos[0])     # 保存视频
            results.append(current_video_path)


    print('infer results:', results)
